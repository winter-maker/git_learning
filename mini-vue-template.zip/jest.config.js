module.exports = {
  testEnvironment: "jsdom",
};
